package fun.cyhgraph.utils;

import com.google.gson.Gson;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class DsUtil {
    private static final String API_KEY =  "sk-99561b877c0f4271b843d3de74531874";
    private static final String URL = "https://api.deepseek.com/chat/completions";

    public static String ask(String content){
        // 创建消息列表
        List<Message> messages = new ArrayList<>();
        messages.add(new Message("user", content));
        // 构建请求体
        ChatRequest requestBody = new ChatRequest(
                "deepseek-chat",  // 模型名称，根据文档调整
                messages,
                0.7,  // temperature
                1000  // max_tokens
        );
        System.out.println(">>>正在提交问题...");
        long startTime = System.currentTimeMillis();
        // 发送请求
        String response = sendRequest(requestBody);
        long endTime = System.currentTimeMillis();
        System.out.println("思考用时："+(endTime-startTime)/1000+"秒");
        return response;
    }

    private static String sendRequest(ChatRequest requestBody) {
        HttpClient client = HttpClient.newHttpClient();
        Gson gson = new Gson();
        //将 ChatRequest 对象中封装的数据转为 JSON 格式
        String requestBodyJson = gson.toJson(requestBody);


        try {
            //构建请求对象 并指定请求头内容格式及身份验证的key
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(URL))
                    .header("Content-Type", "application/json")
                    .header("Accept-Charset", "UTF-8")
                    .header("Authorization", "Bearer " + API_KEY)
                    //将JSON格式的字符串封装为 BodyPublishers 对象
                    .POST(HttpRequest.BodyPublishers.ofString(requestBodyJson))
                    .build();  //构建请求对象

            System.out.println(">>>已提交问题，正在思考中....");
            // 发送请求并获取响应对象
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            //如果响应状态码为成功 200
            if (response.statusCode() == 200) {
//                System.out.println("响应体：");
//                System.out.println(response.body());
                // 确保响应体按 UTF-8 编码处理
                String responseBody = new String(response.body().getBytes(), "UTF-8");
                // 解析响应，将响应体中的 JSON 字符串转为 ChatResponse 对象
                ChatResponse chatResponse = gson.fromJson(responseBody, ChatResponse.class);
                //按 JSON 格式的方式 从自定义的ChatResponse 对象中逐级取出最终的响应对象
                return chatResponse.getChoices().get(0).getMessage().getContent();
            } else {
                return "请求失败，状态码: " + response.statusCode() + ", 响应: " + response.body();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "请求异常: " + e.getMessage();
        }
    }

    // 内部类定义请求/响应结构
    static class Message {
        private String role;
        private String content;

        public Message(String role, String content) {
            this.role = role;
            this.content = content;
        }

        public String getContent() {
            return content;
        }
    }

    /**
     * 请求体的数据内部结构，用于构建请求 JSON
     */
    static class ChatRequest {
        private String model;
        private List<Message> messages;
        private double temperature;
        private int max_tokens;

        public ChatRequest(String model, List<Message> messages, double temperature, int max_tokens) {
            this.model = model;
            this.messages = messages;
            this.temperature = temperature;
            this.max_tokens = max_tokens;
        }
    }


    /**
     * 按着响应的JSON格式来设计响应体
     * 用来封装响应体字符串
     */
    static class ChatResponse {
        private List<Choice> choices;

        public List<Choice> getChoices() {
            return choices;
        }

        static class Choice {
            private Message message;

            public Message getMessage() {
                return message;
            }
        }
    }
}
