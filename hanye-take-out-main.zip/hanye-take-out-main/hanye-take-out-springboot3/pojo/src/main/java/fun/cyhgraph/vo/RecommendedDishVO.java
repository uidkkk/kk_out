package fun.cyhgraph.vo;


import lombok.Data;

@Data
public class RecommendedDishVO {
    private Integer dish_id;       // 菜品编号
    private String dish_name;   // 菜品名称
    private String dish_img;    // 菜品图片
    private String dish_price;  // 菜品价格
    private String dish_des;    // 菜品描述
    private String reason;      // 推荐理由
}
