package fun.cyhgraph.controller.ai;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import fun.cyhgraph.constant.StatusConstant;
import fun.cyhgraph.entity.Dish;
import fun.cyhgraph.mapper.DishMapper;
import fun.cyhgraph.result.Result;
import fun.cyhgraph.utils.DsUtil;
import fun.cyhgraph.vo.RecommendedDishVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/ai")
@Slf4j
public class AiController {
    private final static String prompt = """
    你是一位智慧食堂的菜品推荐助手。
    【任务说明】
    根据用户的输入偏好（如口味、搭配需求等），
    从提供的菜品列表中推荐3~4道最合适的菜品。
    返回结果必须是 **标准 JSON 格式**，且不能包含任何额外的文字说明或解释。
    
    【输入数据】
    我会提供一个菜品列表，每个菜品包含以下字段：
    - dish_id：菜品编号
    - dish_name：菜品名称
    - dish_img：菜品图片URL
    - dish_price：菜品价格
    - dish_des：菜品描述
    
    【输出要求】
    请基于用户输入内容（变量：usermessage）进行菜品推荐。
    输出格式必须严格遵循以下 JSON字符串 模板：
    严禁使用代码块引用起来
    {
      "recommendations": [
        {
          "dish_id": 菜品编号,
          "dish_name": "菜品名称",
          "dish_img": "菜品图片URL",
          "dish_price": "菜品价格",
          "dish_des": "菜品描述",
          "reason": "推荐理由"
        }
      ]
    }
    【示例】
    用户输入："我想吃辣一点的菜"
    菜品列表：
    [
      {"dish_id":1,"dish_name":"麻辣香锅","dish_img":"xxx.jpg","dish_price":"25","dish_des":"香辣可口"},
      {"dish_id":2,"dish_name":"清蒸鱼","dish_img":"xxx.jpg","dish_price":"28","dish_des":"清淡健康"}
    ]
    返回结果示例：
    {
      "recommendations": [
        {
          "dish_id": 1,
          "dish_name": "麻辣香锅",
          "dish_img": "xxx.jpg",
          "dish_price": "25",
          "dish_des": "香辣可口",
          "reason": "麻辣浓郁，适合喜欢重口味的顾客"
        }
      ]
    }
    请根据上述规范生成推荐结果。
    """;

    @Autowired
    private DishMapper dishMapper;

    @GetMapping(value = "/recommend")
    public Result<List<RecommendedDishVO>> recommendDishes(String usermessage){
        //1.查询出全部菜品
        List<Dish> dishes = dishMapper.GetAllDish();
        //2.封装成json字符串
        JSONArray content = String2JSON(dishes, usermessage);
        //3.发送请求
        String res = DsUtil.ask(JSONArray.toJSONString(content));

        //4.解析字符串
        JSONObject jsonObject = JSON.parseObject(res);
        //5.封装返回
        JSONArray recommendationsArray = jsonObject.getJSONArray("recommendations");
        List<RecommendedDishVO> recommendList = recommendationsArray.toJavaList(RecommendedDishVO.class);

        //6.放图片
        for (RecommendedDishVO dish : recommendList) {
            Dish tmp = dishMapper.getById(dish.getDish_id());
            dish.setDish_img(tmp.getPic());
        }

        System.out.println(recommendList);
        return Result.success(recommendList);
    }


    private JSONArray String2JSON(List<Dish> dishes , String usermessage){
        JSONArray dishArray = new JSONArray();
        for (Dish dish : dishes) {
            if (dish.getStatus().equals(StatusConstant.UNABLE))continue;
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("dish_id", dish.getId());
            jsonObject.put("dish_name", dish.getName());
//            jsonObject.put("dish_img" , dish.getPic());
            jsonObject.put("dish_price", dish.getPrice());
            jsonObject.put("dish_des", dish.getDetail());
            dishArray.add(jsonObject);
        }
        JSONObject require = new JSONObject();
        require.put("usermessage", prompt + usermessage);
        dishArray.add(require);
        return dishArray;
    }
}
