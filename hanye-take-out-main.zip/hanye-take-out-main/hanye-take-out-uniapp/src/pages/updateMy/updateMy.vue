<template>
  <view class="update-container">
    <!-- 顶部导航栏 -->
    <view class="update-navbar">
      <view class="back-btn" @click="goBack">
        <text class="arrow">←</text>
        <text class="label">返回</text>
      </view>
      <view class="nav-title">编辑资料</view>
    </view>

  <!-- 信息input框列表 -->
  <view class="submit">
    <form @submit="submit">
      <view class="pic_box" @click="picChange">
        <image v-if="!user.pic" src="../../static/images/user_default.png" mode="aspectFill"></image>
        <image v-else :src="user.pic" mode="aspectFill"></image>
        <view class="text">点击上传头像</view>
      </view>
      <view class="radio">
        <view class="radio-item" v-for="(item, index) in items" :key="index" @click="genderChange(item.value)">
          <image v-if="item.value != user.gender" class="radio-img" src="../../static/icon/icon-radio.png"></image>
          <image v-else class="radio-img" src="../../static/icon/icon-radio-selected.png"></image>
          <text class="radio-label">{{ item.name }}</text>
        </view>
      </view>
      <view class="item">
        <view class="title">昵称</view>
        <input class="item_input" placeholder="请输入昵称" v-model="user.name" />
      </view>
      <view class="item">
        <view class="title">手机号</view>
        <input class="item_input" placeholder="请输入手机号" v-model="user.phone" />
      </view>
      <button form-type="submit" class="submit_btn">确认修改</button>
    </form>
    </view>
  </view>
</template>

<script lang="ts" setup>
import {ref, reactive} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import {useUserStore} from '@/stores/modules/user'
import {getUserInfoAPI, updateUserAPI} from '@/api/user'

const userStore = useUserStore()

const user = reactive({
  id: userStore.profile!.id,
  name: '',
  gender: 1,
  phone: '未设置',
  pic: '',
})
const items = [
  {
    value: 1,
    name: '男士',
  },
  {
    value: 0,
    name: '女士',
  },
]

onLoad(async () => {
  console.log('userStore', userStore.profile)
  await getUserInfo(user.id)
})

const getUserInfo = async (id: number) => {
  const res = await getUserInfoAPI(id)
  console.log('用户信息', res)
  user.name = res.data.name as string
  user.gender = res.data.gender ?? 1 // 之前没设置就默认男士
  user.phone = res.data.phone as string
  user.pic = res.data.pic as string
  console.log('user', user)
}

const picChange = () => {
  console.log('picChange')
  // #ifdef MP-WEIXIN
  // 微信小程序环境
  uni.chooseMedia({
    count: 1,
    mediaType: ['image'],
    sourceType: ['album', 'camera'],
    maxDuration: 15,
    camera: 'back',
    success: (res) => {
      console.log(res)
      const {tempFilePath} = res.tempFiles[0]
      let base64String = ''
      wx.getFileSystemManager().readFile({
        filePath: tempFilePath,
        encoding: 'base64',
        success: (res) => {
          base64String = 'data:image/png;base64,' + res.data
          console.log(base64String)
          user.pic = base64String
        },
      })
    },
  })
  // #endif

  // #ifdef H5
  // H5 环境使用 chooseImage
  uni.chooseImage({
    count: 1,
    sizeType: ['compressed'],
    sourceType: ['album'],
    success: (res) => {
      console.log('H5 选择图片成功:', res)
      const tempFilePath = res.tempFilePaths[0]
      
      // H5 环境下，tempFilePath 是 blob URL，可以直接使用
      // 或者转换为 base64（如果后端需要）
      // 对于 H5，我们可以直接使用 blob URL 显示图片
      user.pic = tempFilePath
      console.log('H5 设置图片路径:', tempFilePath)
      
      // 如果需要转换为 base64，可以使用以下方法
      // 但在 UniApp H5 中，通常直接使用 tempFilePath 即可
    },
    fail: (err) => {
      console.error('H5 选择图片失败:', err)
      uni.showToast({
        title: '选择图片失败',
        icon: 'none',
      })
    },
  })
  // #endif
}
const genderChange = (val: number) => {
  user.gender = val
  console.log(user.gender)
}

const validateForm = (): boolean => {
  let valid = true
  // 验证昵称
  if (!user.name) {
    uni.showToast({
      title: '昵称不能为空',
      icon: 'none',
    })
    valid = false
  }
  // 验证手机号格式
  const phonePattern = /^1[3-9]\d{9}$/
  if (!user.phone) {
    uni.showToast({
      title: '手机号不能为空',
      icon: 'none',
    })
    valid = false
  } else if (!phonePattern.test(user.phone)) {
    uni.showToast({
      title: '手机号格式不正确',
      icon: 'none',
    })
    valid = false
  }
  return valid
}

const submit = async () => {
  console.log('submit', user)
  if (!validateForm()) {
    return
  }
  const res = await updateUserAPI(user)
  if (res.code === 0) {
    uni.showToast({
      title: '修改成功',
      icon: 'success',
    })
    uni.switchTab({
      url: '/pages/my/my',
    })
  }
}

// 返回
const goBack = () => {
  const pages = getCurrentPages()
  if (pages.length > 1) {
    uni.navigateBack()
  } else {
    uni.switchTab({
      url: '/pages/my/my',
    })
  }
}
</script>

<style lang="less" scoped>
.update-container {
  min-height: 100vh;
  padding-top: 100rpx;
  box-sizing: border-box;

  // #ifdef H5
  background: #eef3f8;
  padding-bottom: 40rpx;
  // #endif
}

.update-navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30rpx 60rpx;
  background: linear-gradient(135deg, #22ccff 0%, #0095ff 100%);
  box-shadow: 0 8rpx 24rpx rgba(0, 0, 0, 0.08);

  .back-btn {
    display: flex;
    align-items: center;
    gap: 16rpx;
    font-size: 30rpx;
    color: #fff;
    cursor: pointer;
    font-weight: 500;
  }

  .nav-title {
    flex: 1;
    text-align: center;
    font-size: 34rpx;
    font-weight: 600;
    color: #fff;
    margin-right: 60rpx;
  }
}

.submit {
  margin: 20rpx 30rpx;

  // #ifdef H5
  max-width: 750rpx;
  margin: 0 auto;
  padding: 40rpx;
  background: #fff;
  border-radius: 24rpx;
  box-shadow: 0 12rpx 40rpx rgba(20, 42, 70, 0.05);
  // #endif

  .pic_box {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 30rpx;
    position: relative;
    cursor: pointer;

    // #ifdef H5
    margin-top: 0;
    margin-bottom: 40rpx;
    padding: 40rpx 0;
    background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
    border-radius: 16rpx;
    transition: all 0.3s;
    &:hover {
      background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);
      transform: translateY(-2rpx);
    }
    // #endif

    image {
      width: 120rpx;
      height: 120rpx;
      border-radius: 50%;

      // #ifdef H5
      width: 160rpx;
      height: 160rpx;
      border: 4rpx solid #fff;
      box-shadow: 0 8rpx 20rpx rgba(34, 204, 255, 0.2);
      // #endif
    }
    .text {
      font-size: 25rpx;
      line-height: 50rpx;
      color: #666;

      // #ifdef H5
      font-size: 28rpx;
      color: #0891b2;
      font-weight: 500;
      // #endif
    }
  }
  .radio {
    height: 110rpx;
    font-size: 26rpx;
    text-align: left;
    color: #333333;
    letter-spacing: 0px;
    display: flex;
    padding-right: 20rpx;
    justify-content: center;

    // #ifdef H5
    padding: 20rpx 0;
    background: #f8fafc;
    border-radius: 12rpx;
    margin-bottom: 30rpx;
    // #endif

    .radio-item {
      display: flex;
      align-items: center;
      cursor: pointer;

      &:first-child {
        margin-right: 54rpx;
      }

      // #ifdef H5
      padding: 10rpx 30rpx;
      transition: all 0.3s;
      &:hover {
        background: #e0f2fe;
        border-radius: 8rpx;
      }
      // #endif
    }

    .radio-img {
      width: 32rpx;
      height: 32rpx;
      margin-right: 10rpx;
    }
  }
  .item {
    height: 110rpx;
    line-height: 110rpx;
    border-bottom: 1px solid #efefef;
    display: flex;

    // #ifdef H5
    border-bottom: 2px solid #f1f5f9;
    padding: 0 20rpx;
    margin: 0 -20rpx;
    &:last-of-type {
      border-bottom: none;
    }
    // #endif

    image {
      width: 40rpx;
      height: 40rpx;
      margin-right: 20rpx;
    }
    .title {
      width: 120rpx;
      font-size: 30rpx;
      color: #333;

      // #ifdef H5
      font-weight: 500;
      color: #475569;
      // #endif
    }
    .item_input {
      flex: 1;
      height: 110rpx;
      line-height: 110rpx;
      font-size: 30rpx;
      color: #666;

      // #ifdef H5
      color: #1e293b;
      // #endif
    }
  }
  .submit_btn {
    width: 600rpx;
    height: 80rpx;
    line-height: 80rpx;
    border-radius: 40rpx;
    background: #22ccff;
    border: none;
    color: #fff;
    font-size: 30rpx;
    text-align: center;
    margin: 40rpx auto;

    // #ifdef H5
    width: 100%;
    height: 88rpx;
    line-height: 88rpx;
    border-radius: 999rpx;
    font-size: 32rpx;
    font-weight: 600;
    box-shadow: 0 12rpx 24rpx rgba(34, 204, 255, 0.3);
    cursor: pointer;
    transition: all 0.3s;
    &:hover {
      background: #00aaff;
      box-shadow: 0 16rpx 32rpx rgba(34, 204, 255, 0.4);
      transform: translateY(-2rpx);
    }
    // #endif
  }
}
</style>
