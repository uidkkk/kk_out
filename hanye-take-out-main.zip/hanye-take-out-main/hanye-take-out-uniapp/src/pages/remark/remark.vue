<template>
  <view class="remark-container">
    <!-- 顶部导航栏 -->
    <view class="remark-navbar">
      <view class="back-btn" @click="goBack">
        <text class="arrow">←</text>
        <text class="label">返回</text>
      </view>
      <view class="nav-title">订单备注</view>
    </view>

    <view class="content-wrapper">
  <view class="uni-textarea">
    <textarea
      class="remark_text"
      placeholder-class="textarea-placeholder"
      v-model="remark"
      :maxlength="50"
      placeholder="请输入您需要备注的信息"
    />
    <view class="fifty">{{ remark.length }} / 50</view>
  </view>
    </view>

  <view class="add_address">
    <button class="add_btn" :plain="true" @click="returnToSubmit()">完成</button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import {ref} from 'vue'

const remark = ref('')

// 返回提交页面，把备注信息传递给store
const returnToSubmit = () => {
  console.log('remark', remark.value)
  uni.redirectTo({
    url: '/pages/submit/submit?remark=' + remark.value,
  })
}

// 返回
const goBack = () => {
  const pages = getCurrentPages()
  if (pages.length > 1) {
    uni.navigateBack()
  } else {
    uni.redirectTo({
      url: '/pages/submit/submit',
    })
  }
}
</script>

<style lang="less" scoped>
.remark-container {
  min-height: 100vh;
  padding-top: 100rpx;
  box-sizing: border-box;

  // #ifdef H5
  background: #eef3f8;
  padding-bottom: 40rpx;
  // #endif
}

.remark-navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30rpx 60rpx;
  background: linear-gradient(135deg, #22ccff 0%, #0095ff 100%);
  box-shadow: 0 8rpx 24rpx rgba(0, 0, 0, 0.08);

  .back-btn {
    display: flex;
    align-items: center;
    gap: 16rpx;
    font-size: 30rpx;
    color: #fff;
    cursor: pointer;
    font-weight: 500;
  }

  .nav-title {
    flex: 1;
    text-align: center;
    font-size: 34rpx;
    font-weight: 600;
    color: #fff;
    margin-right: 60rpx;
  }
}

.content-wrapper {
  // #ifdef H5
  max-width: 750rpx;
  margin: 0 auto;
  padding: 40rpx;
  // #endif
}

// 添加的备注
.uni-textarea {
  margin: 30rpx;
  padding-left: 30rpx;
  box-sizing: border-box;
  width: 690rpx;
  height: 300rpx;
  opacity: 1;
  background: #eee;
  border-radius: 12rpx;
  padding-top: 20rpx;
  font-size: 26rpx;

  // #ifdef H5
  margin: 0;
  width: 100%;
  height: 400rpx;
  background: #fff;
  border-radius: 24rpx;
  box-shadow: 0 12rpx 40rpx rgba(20, 42, 70, 0.05);
  padding: 40rpx;
  // #endif

  .remark_text {
    line-height: 60rpx;
    height: 200rpx;

    // #ifdef H5
    height: 280rpx;
    font-size: 28rpx;
    line-height: 50rpx;
    // #endif
  }
  .fifty {
    color: #bbbbbb;

    // #ifdef H5
    text-align: right;
    color: #999;
    font-size: 24rpx;
    margin-top: 10rpx;
    // #endif
  }
}

.add_address {
  position: fixed;
  bottom: 0rpx;
  left: 0;
  margin: 0 auto;
  background: #ffffff;
  height: 136rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 750rpx;

  // #ifdef H5
  position: static;
  max-width: 750rpx;
  margin: 40rpx auto 0;
  background: transparent;
  height: auto;
  padding: 0 40rpx;
  // #endif

  .add_btn {
    width: 668rpx;
    height: 72rpx;
    line-height: 72rpx;
    border-radius: 72rpx;
    background: #ffc200;
    border: 1px solid #ffc200;
    opacity: 1;
    font-size: 30rpx;
    font-family: PingFangSC, PingFangSC-Medium;
    font-weight: 500;
    text-align: center;
    color: #333333;
    letter-spacing: 0px;
    display: flex;
    align-items: center;
    justify-content: center;

    // #ifdef H5
    width: 100%;
    height: 88rpx;
    line-height: 88rpx;
    border-radius: 999rpx;
    font-size: 32rpx;
    font-weight: 600;
    background: linear-gradient(135deg, #ffd700 0%, #ffc200 100%);
    box-shadow: 0 12rpx 24rpx rgba(255, 194, 0, 0.3);
    cursor: pointer;
    transition: all 0.3s;
    &:hover {
      background: linear-gradient(135deg, #ffc200 0%, #ffb000 100%);
      box-shadow: 0 16rpx 32rpx rgba(255, 194, 0, 0.4);
      transform: translateY(-2rpx);
    }
    // #endif
  }
}
</style>
