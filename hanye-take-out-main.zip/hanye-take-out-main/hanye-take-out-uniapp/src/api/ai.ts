import type { RecommendedDishVO } from '@/types/ai'
import { http } from '@/utils/http'

/**
 * AI 推荐菜品
 * @param usermessage 用户需求描述
 */
export const recommendDishesAPI = (usermessage: string) => {
  console.log('【AI接口】发送推荐请求，设置 timeout:', 180000)
  console.log('【AI接口】用户需求:', usermessage)
  return http<RecommendedDishVO[]>({
    method: 'GET',
    url: `/ai/recommend?usermessage=${encodeURIComponent(usermessage)}`,
    timeout: 180000, // AI 接口响应较慢，设置 60 秒超时
  })
}



