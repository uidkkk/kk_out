<script setup lang="ts">
import {onLaunch, onShow, onHide} from '@dcloudio/uni-app'
onLaunch(() => {
  console.log('App Launch')
})
onShow(() => {
  console.log('App Show')
})
onHide(() => {
  console.log('App Hide')
})
</script>

<style>
@import '@/static/styles/iconfont.css';

/* H5 浏览器适配：限制最大宽度并居中显示 */
/* #ifdef H5 */
page {
  max-width: 750px;
  margin: 0 auto;
  box-shadow: 0 0 30px rgba(0, 0, 0, 0.15);
  background-color: #fff;
}

body {
  background-color: #f5f5f5;
}
/* #endif */
</style>
